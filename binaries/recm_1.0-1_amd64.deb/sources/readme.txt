apt-get update
apt install gcc

apt-get install libncurses-dev
apt-get install libpq-dev
apt-get install libzip
apt-get install libzip-dev
apt-get install zip



   30  ifup
   31  cat /etc/network/interfaces/
   32  cat /etc/network/interfaces
   33  cat /etc/hostname
   34  vi  /etc/hostname
   35  vi  /etc/resolv.conf 
   36  cat /etc/network/interfaces
   37  ls -l /etc/network/interfaces.d/
   38  cat /etc/network/interfaces
   39  vi /etc/network/interfaces
   40  reboot now
   41  vi /etc/hosts
   42  nslookup `hostname`
   43  ping rsvm182
   45  passwd 
   46  exit
   47  uname -a
   48  pwd
   49  ll
   50  alias ll='l -ltr'
   51  ll
   52  alias ll='l -ltr';
   53  ll
   54  alias
   55  alias ll='ls -ltr';
   56  ll
   57  cd recm
   58  ll
   59  pwd
   60  mkdir sources
   61  cd sources
   62  pwd
   63  tar -xvf /tmp/recm_centos.tar 
   68  ll
   69  vi gcc_recm
   70  apt-get install postgres
   71  apt-get install postgresql-12
   72  ll
   73  cd
   74  cat /tmp/debian_repo 
   75  apt update
   76  apt install gnupg2
   77  cat /tmp/debian_repo 
   78  wget --quiet -O - https://www.postgresql.org/media/keys/ACCC4CF8.asc|apt-key add -
   79  echo "deb http://apt.postgresql.org/pub/repos/apt/ `lsb_release -cs`-pgdg main"|tee /etc/apt/sources.list.d/pgdg.list
   80  apt install postgresql-12
   81  cat /etc/apt/sources.list
   82  echo "deb http://apt.postgresql.org/pub/repos/apt/ `lsb_release -cs`-pgdg main"|tee /etc/apt/sources.list.d/pgdg.list
   83  cat /etc/apt/sources.list.d/pgdg.list 
   84  cat /etc/apt/sources.list
   85  cat /etc/apt/sources.list.d/pgdg.list >>/etc/apt/sources.list
   86  apt install postgresql-12
   87  vi /etc/apt/sources.list
   88  apt install postgresql
   89  apt install postgresql-13
   90  type pg_ctl
   91  /usr/bin/pg_ctl --version
   92  fin /usr -name "pg_ctl"
   93  find /usr -name "pg_ctl"
   94  alias pg_ctl=`/usr/lib/postgresql/13/bin/pg_ctl'
   95  alias pg_ctl='/usr/lib/postgresql/13/bin/pg_ctl'
   96  alias psql='/usr/lib/postgresql/13/bin/psql'
   97  pg_ctl --version
   98  su - postgres
   99  find / -name "libpq*"
  100  find / -name "*.h"|grep -i postg
  101  find / -name "*.h"|grep -i pg
  102  more /usr/include/linux/pg.h
  103  cd
  104  cd recm
  105  ls -l
  106  cd sources/
  107  ls -ltr
  108  chmod 755 gcc_recm 
  109  ./gcc_recm 
  110  vi gcc_recm 
  111  ./gcc_recm 
  112  vi gcc_recm 
  113  ./gcc_recm 
  114  vi gcc_recm 
  115  ./gcc_recm 
  116  find / -name "libpq-fe.h"
  118  find / -name "libpq-fe.h"
  119  vi gcc_recm 
  120  find / -name "libpq-fe.h"
  121  vi gcc_recm 
  122  find / -name "libpq-fe.h"
  123  vi gcc_recm 
  124  find / -name "libpq-fe.h"
  125  ./gcc_recm 
  126  find / -name "zip.h"
  128  find / -name "zip.h"
  129  ./gcc_recm 
  131  ./gcc_recm 
  132  find / -name "libpq*"
  133  vi ./gcc_recm 
  134  find / -name "libpq.so"
  135  vi ./gcc_recm 
  136  ./gcc_recm 
  137  vi ./gcc_recm 
  138  find / -name "libpq.a"
  139  vi ./gcc_recm 
  140  ./gcc_recm 
  141  vi ./gcc_recm 
  142  ./gcc_recm 
  143  ./gcc_recm >a.log
  144  vi a.log
  145  ./gcc_recm 2>a.log
  146  vi a.log
  147  history
  148  history >a.log
