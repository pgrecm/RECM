/* create restore point  /name="<name>";
                         /verbose
*/
void COMMAND_CREATERP(int idcmd,char *command_line)
{
   if (isConnectedAndRegistered() == false) return;
   
   // Change verbosity
   int opt_verbose=optionIsSET("opt_verbose");
   int saved_verbose=globalArgs.verbosity;
   globalArgs.verbosity=opt_verbose;
   
   memBeginModule();

   char *query=memAlloc(1024);
   char *restore_point_type=memAlloc(10);
   strcpy(restore_point_type,"T");
   
   // Set TEMPORARY restore point by default
   if (optionIsUNSET("opt_temporary") == true && optionIsUNSET("opt_permanent") == true)
   {
      SETOption("opt_temporary");
   }
   
   if (optionIsUNSET("opt_temporary") == true && optionIsUNSET("opt_permanent") == true)
   {
      ERROR(ERR_BADOPTION,"Please, choose between '/temporary' or '/permanent'. Both are not accepted.\n");
      globalArgs.verbosity=saved_verbose;
      memEndModule();
      return;
   }
   if (optionIsSET("opt_temporary") == true) { strcpy(restore_point_type,"T"); };
   if (optionIsSET("opt_permanent") == true) { strcpy(restore_point_type,"P"); };

   if (qualifierIsUNSET("qal_name") == true)
   {
      ERROR(ERR_MISQUALVAL,"Missing /name=xxx qualifier.\n");
      globalArgs.verbosity=saved_verbose;
      memEndModule();
      return;
   };
   if (isValidName(varGet("qal_name")) == false)
   {
      ERROR(ERR_INVCHARINNAME,"Invalid character in name '%s'\n",varGet("qal_name"));
      globalArgs.verbosity=saved_verbose;
      memEndModule();
      return;
   }
   sprintf(query,"select count(*) from %s.backup_rp where cid=%s and lower(rp_name) = lower('%s')",
                 varGet(GVAR_DEPUSER),
                 varGet(GVAR_CLUCID),
                 varGet("qal_name"));
   int row=DEPOquery(query,0);
   if (DEPOgetInt(0,0) != 0)
   {
      ERROR(ERR_NAMEEXIST,"Restore point name '%s' already exist.\n",varGet("qal_name"));
      DEPOqueryEnd();
      globalArgs.verbosity=saved_verbose;
      memEndModule();
      return;
   }
   DEPOqueryEnd();
   
   sprintf(query,"select pg_create_restore_point('%s');",varGet("qal_name"));
   row=CLUquery(query,0);
   if (row != 1)
   {
      ERROR(ERR_CREATRPFAILED,"Could not create restore point '%s'\n",varGet("qal_name"));
      CLUqueryEnd();
      globalArgs.verbosity=saved_verbose;
      memEndModule();
      return;
   }
   char *lsn=memAlloc(128);
   char *walfile=memAlloc(128);
   strcpy(lsn,CLUgetString(0,0));
   CLUqueryEnd();
      
   sprintf(query,"select pg_walfile_name('%s');",lsn);
   row=CLUquery(query,0);
   if (row != 1)
   {
      ERROR(ERR_CREATRPFAILED,"Could not create restore point '%s'\n",varGet("qal_name"));
      globalArgs.verbosity=saved_verbose;
      memEndModule();
      return;
   }
   strcpy(walfile,CLUgetString(0,0));
   CLUqueryEnd();
   
   // Force a switch WAL
   cluster_doSwitchWAL(true);

   VERBOSE("Restore point '%s' created at '%s' (WAL %s)\n",varGet("qal_name"),lsn,walfile);

   sprintf(query,"insert into %s.backup_rp(cid,rp_name,lsn,tl,wal,rp_typ) values(%s,lower('%s'),'%s',%ld,'%s','%s')",
                 varGet(GVAR_DEPUSER),
                 varGet(GVAR_CLUCID),
                 varGet("qal_name"),
                 lsn,
                 pgGetCurrentTimeline(),
                 walfile,
                 restore_point_type);
   int rc=DEPOquery(query,0);
   DEPOqueryEnd();
   globalArgs.verbosity=saved_verbose;
   memEndModule();
   return;
};

   