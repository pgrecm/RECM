/* delete cluster  /cid=<cluster_id>
                         /verbose
*/
void COMMAND_DELETECLUSTER(int idcmd,char *command_line)
{
   if (DEPOisConnected() == false) 
   {
      ERROR(ERR_NOTCONNECTED,"Not connected to any deposit.\n");
      return;
   }
   
   // Change verbosity
   int opt_verbose=optionIsSET("opt_verbose");
   int saved_verbose=globalArgs.verbosity;
   globalArgs.verbosity=opt_verbose;

   // Refuse to delete currently connected cluster.
   long current_CID=varGetLong(GVAR_CLUCID);
   if (current_CID == varGetLong("qal_cid") && current_CID != 0)
   {
      ERROR(ERR_INVCLUID,"Cannot delete current connected cluster ID %ld\n",current_CID);
      return;
   }
   memBeginModule();
   char *query=memAlloc(1024);
   sprintf(query,"select clu_nam,clu_sts from %s.clusters where cid=%s",
                 varGet(GVAR_DEPUSER),
                 varGet("qal_cid"));
   int row=DEPOquery(query,0);
   if (row == 0)
   {
      ERROR(ERR_CIDNOTFOUND,"CID '%s' not found in DEPOSIT.\n",varGet("qal_cid"));
      DEPOqueryEnd();
      memEndModule();
      return;
   }
   char *cluster_name=memAlloc(128);  strcpy(cluster_name,  DEPOgetString(0,0));
   char *cluster_status=memAlloc(128);strcpy(cluster_status,DEPOgetString(0,1));
   DEPOqueryEnd();
   TRACE("cluster_status='%s'\n",cluster_status);
   TRACE("CLUSTER_STATE_ENABLED='%s'\n",CLUSTER_STATE_ENABLED);
   TRACE("opt_force='%s'\n",varGet("opt_force"));
   TRACE("VAR_SET_VALUE='%s'\n",VAR_SET_VALUE);
   if (strcmp(cluster_status,CLUSTER_STATE_ENABLED) == 0 && optionIsSET("opt_force")==false)
   {
      ERROR(ERR_CLUSTERENABLED,"Cluster '%s' is enabled. Use '/force' option or disable first the cluster.\n",
                               cluster_name);
      memEndModule();
      return;
   };
 
   sprintf(query,"delete from %s.backup_dbs where cid=%s\n",varGet(GVAR_DEPUSER),varGet("qal_cid"));
   row=DEPOquery(query,0);
   DEPOqueryEnd();
   printf(".");
   sprintf(query,"delete from %s.backup_ndx where cid=%s\n",varGet(GVAR_DEPUSER),varGet("qal_cid"));
   row=DEPOquery(query,0);
   DEPOqueryEnd();
   printf(".");
   sprintf(query,"delete from %s.backup_pieces where cid=%s\n",varGet(GVAR_DEPUSER),varGet("qal_cid"));
   row=DEPOquery(query,0);
   DEPOqueryEnd();
   printf(".");
   sprintf(query,"delete from %s.backup_rp where cid=%s\n",varGet(GVAR_DEPUSER),varGet("qal_cid"));
   row=DEPOquery(query,0);
   DEPOqueryEnd();
   printf(".");
   sprintf(query,"delete from %s.backup_tbl where cid=%s\n",varGet(GVAR_DEPUSER),varGet("qal_cid"));
   row=DEPOquery(query,0);
   DEPOqueryEnd();
   printf(".");
   sprintf(query,"delete from %s.backup_tbs where cid=%s\n",varGet(GVAR_DEPUSER),varGet("qal_cid"));
   row=DEPOquery(query,0);
   DEPOqueryEnd();
   printf(".");
   sprintf(query,"delete from %s.backup_wals where cid=%s\n",varGet(GVAR_DEPUSER),varGet("qal_cid"));
   row=DEPOquery(query,0);
   DEPOqueryEnd();
   printf(".");
   sprintf(query,"delete from %s.backups where cid=%s\n",varGet(GVAR_DEPUSER),varGet("qal_cid"));
   row=DEPOquery(query,0);
   DEPOqueryEnd();
   printf(".");
   sprintf(query,"delete from %s.clusters where cid=%s\n",varGet(GVAR_DEPUSER),varGet("qal_cid"));
   row=DEPOquery(query,0);
   DEPOqueryEnd();
   printf(".\nCluster '%s' deleted.\n",cluster_name);
  
   globalArgs.verbosity=saved_verbose;
   memEndModule();
   return;
};

   